package edu.uco.budget.crosscutting.exception.enumeration;

public enum LayerException {
	
	CROSSCUTTING, DATA, SERVICE, DOMAIN, API, APPLICATION
	
}
